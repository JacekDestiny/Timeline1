$(document).foundation();

$(document).ready(function(){
  //default
  var timeline1='tml1';
  var wrap='wrap1';
  var cont_m='n1';

  if(timeline1=='tml1') $("#ar1").removeClass('one two three four five').addClass('one');
  // ar1	tml1 id="wrap1"   .events-wrapper a

  $("#tml1").on("click", function(){
    timeline1='tml1';
	 $("#ar1").removeClass('one two three four five').addClass('one');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml1").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap1").removeClass('selected').addClass('selected');
    wrap='wrap1';
	 $("#symb").css("left","-599px");
	 var obj = $("#"+wrap);
	 var property="translateX";
	 obj.css({
		  		"-webkit-transform": property + "(0px)",
				"-moz-transform": property + "(0px)",
				"-ms-transform": property + "(0px)",
				"-o-transform": property + "(0px)",
				"transform": property + "(0px)"
	 });
  });

  $("#tml2").on("click", function(){
    timeline1='tml2';
	 $("#ar1").removeClass('one two three four five').addClass('two');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml2").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap2").removeClass('selected').addClass('selected');
	 wrap='wrap2';
	 $("#symb").css("left","-599px");
	 var obj = $("#"+wrap);
	 var property="translateX";
	 obj.css({
		  		"-webkit-transform": property + "(0px)",
				"-moz-transform": property + "(0px)",
				"-ms-transform": property + "(0px)",
				"-o-transform": property + "(0px)",
				"transform": property + "(0px)"
	 });
  });

    $("#tml3").on("click", function(){
    timeline1='tml3';
	 $("#ar1").removeClass('one two three four five').addClass('three');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml3").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap3").removeClass('selected').addClass('selected');
	 wrap='wrap3';
	 $("#symb").css("left","-599px");
	 var obj = $("#"+wrap);
	 var property="translateX";
	 obj.css({
		  		"-webkit-transform": property + "(0px)",
				"-moz-transform": property + "(0px)",
				"-ms-transform": property + "(0px)",
				"-o-transform": property + "(0px)",
				"transform": property + "(0px)"
	 });
  });

    $("#tml4").on("click", function(){
    timeline1='tml4';
	 $("#ar1").removeClass('one two three four five').addClass('four');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml4").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap4").removeClass('selected').addClass('selected');
	 wrap='wrap4';
	 $("#symb").css("left","-599px");
	 var obj = $("#"+wrap);
	 var property="translateX";
	 obj.css({
		  		"-webkit-transform": property + "(0px)",
				"-moz-transform": property + "(0px)",
				"-ms-transform": property + "(0px)",
				"-o-transform": property + "(0px)",
				"transform": property + "(0px)"
	 });
  });

    $("#tml5").on("click", function(){
    timeline1='tml5';
	 $("#ar1").removeClass('one two three four five').addClass('five');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml5").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap5").removeClass('selected').addClass('selected');
	 wrap='wrap5';
	 $("#symb").css("left","-599px");
	 var obj = $("#"+wrap);
	 var property="translateX";
	 obj.css({
		  		"-webkit-transform": property + "(0px)",
				"-moz-transform": property + "(0px)",
				"-ms-transform": property + "(0px)",
				"-o-transform": property + "(0px)",
				"transform": property + "(0px)"
	 });
  });

  $(".nav_tl .prev").on("click", function(){
	var lcont=	parseInt(cont_m.replace("n",""));
     if(lcont>=10) {

	    var obj = $("#"+wrap);
		 var trans=obj.css("transform")||obj.css("-moz-transform")||obj.css("-ms-transform")||obj.css("-o-transform")||obj.css("-webkit-transform");
		 var mt=trans.replace(/[^0-9\-.,]/g, '').split(',');
		 var x = mt[12] || mt[4];//translate x   mo�e by� wrap: wrap1 trans00: undefined
       var y = mt[13] || mt[5];//translate y


		 var li=wrap.replace("wrap","");

	  	 event.preventDefault();
	  } else {

		 var obj = $("#"+wrap);
	    var trans=obj.css("transform")||obj.css("-moz-transform")||obj.css("-ms-transform")||obj.css("-o-transform")||obj.css("-webkit-transform");
		 var mt=trans.replace(/[^0-9\-.,]/g, '').split(',');
		 var x = mt[12] || mt[4];//translate x   mo�e by� wrap: wrap1 trans00: undefined
       var y = mt[13] || mt[5];//translate y

		 var li=wrap.replace("wrap","");

		 if(typeof x==="undefined"){
		    var size= "-530px";
		 } else {
		   if(x!=0){
			  var size1= (parseInt(x/1)+parseInt(x/(lcont-1)));
			  var size= (size1)+"px";
			}else {
			  var size1= (parseInt(-530));
			  var size= (size1)+"px";
			}

		 }

		 var property="translateX";
		 obj.css({
		  		"-webkit-transform": property + "("+size+")",
				"-moz-transform": property + "("+size+")",
				"-ms-transform": property + "("+size+")",
				"-o-transform": property + "("+size+")",
				"transform": property + "("+size+")"
		 });
		 var symb=$("#symb").css("left");
		 symb=symb.replace("px","");
		 var symbw=$("#symb").css("width");
		 symbw=symbw.replace("px","");
		 cont_m='n'+parseInt(lcont+1);
		 symb=parseInt(symb)+parseInt(symbw/9);
		 $("#symb").css("left",symb+"px");

	  }


  });

  $(".nav_tl .next").on("click", function(){

	var lcont=	parseInt(cont_m.replace("n",""));

     if(lcont<=1) {

	    var obj = $("#"+wrap);
		 var trans=obj.css("transform")||obj.css("-moz-transform")||obj.css("-ms-transform")||obj.css("-o-transform")||obj.css("-webkit-transform");
		 var mt=trans.replace(/[^0-9\-.,]/g, '').split(',');
		 var x = mt[12] || mt[4];//translate x   mo�e by� wrap: wrap1 trans00: undefined
       var y = mt[13] || mt[5];//translate y

		 var li=wrap.replace("wrap","");

	  	 event.preventDefault();
	  }else {

		 var obj = $("#"+wrap);
	    var trans=obj.css("transform")||obj.css("-moz-transform")||obj.css("-ms-transform")||obj.css("-o-transform")||obj.css("-webkit-transform");
		 var mt=trans.replace(/[^0-9\-.,]/g, '').split(',');
		 var x = mt[12] || mt[4];//translate x   mo�e by� wrap: wrap1 trans00: undefined
       var y = mt[13] || mt[5];//translate y

		 var li=wrap.replace("wrap","");

		 if(typeof x==="undefined"){
		    var size= "-530px";
		 } else {
			var size1= (parseInt(x/1)-parseInt(x/(lcont-1)));
			var size= (size1)+"px";
		 }

		 var property="translateX";
		 obj.css({
		  		"-webkit-transform": property + "("+size+")",
				"-moz-transform": property + "("+size+")",
				"-ms-transform": property + "("+size+")",
				"-o-transform": property + "("+size+")",
				"transform": property + "("+size+")"
		 });
		 var symb=$("#symb").css("left");
		 symb=symb.replace("px","");
		 var symbw=$("#symb").css("width");
		 symbw=symbw.replace("px","");
		 cont_m='n'+parseInt(lcont-1);
		 symb=parseInt(symb)-parseInt(symbw/9);
		 $("#symb").css("left",symb+"px");


	  }
	});


});

console.log('Start javy 1');