$(document).foundation();
// develop Jacek Latocha 02.2020
$(document).ready(function(){
  //default
  var timeline1='tml1';
  var wrap='wrap1';
  var cont_m='n1';

  if(timeline1=='tml1') $("#ar1").removeClass('one two three four five').addClass('one');

  $("#tml1").on("click", function(){
    timeline1='tml1';
	 $("#ar1").removeClass('one two three four five').addClass('one');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml1").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap1").removeClass('selected').addClass('selected');
    wrap='wrap1';


  });

    $("#tml2").on("click", function(){
    timeline1='tml2';
	 $("#ar1").removeClass('one two three four five').addClass('two');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml2").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap2").removeClass('selected').addClass('selected');
	 wrap='wrap2';
  });

    $("#tml3").on("click", function(){
    timeline1='tml3';
	 $("#ar1").removeClass('one two three four five').addClass('three');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml3").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap3").removeClass('selected').addClass('selected');
	 wrap='wrap3';
  });

    $("#tml4").on("click", function(){
    timeline1='tml4';
	 $("#ar1").removeClass('one two three four five').addClass('four');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml4").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap4").removeClass('selected').addClass('selected');
	 wrap='wrap4';
  });

    $("#tml5").on("click", function(){
    timeline1='tml5';
	 $("#ar1").removeClass('one two three four five').addClass('five');

	 $(".events-wrapper a").removeClass('selected');
	 $("#tml5").removeClass('selected').addClass('selected');
	 $("#wrap_tl .wrap_time").removeClass('selected');
	 $("#wrap5").removeClass('selected').addClass('selected');
	 wrap='wrap5';
  });

  $(".nav_tl .prev").on("click", function(){
     if(cont_m=='n1') {
	  	 event.preventDefault();
	  } else {
		 var obj = $("#"+wrap);
	    var trans=obj.css("transform")||obj.css("-moz-transform")||obj.css("-ms-transform")||obj.css("-o-transform")||obj.css("-webkit-transform");
		 var mt=trans.replace(/[^0-9\-.,]/g, '').split(',');
		 var x = mt[12] || mt[4];//translate x   mo�e by� wrap: wrap1 trans00: undefined
       var y = mt[13] || mt[5];//translate y
		 var li=wrap.replace("wrap","");
		 var lcont=	cont_m.replace("n","");
		 if(typeof x==="undefined"){
		 } else {
		   var size= x/li+"px";
			var property="translateX"
		   obj.css({
		  		"-webkit-transform": property + "("+size+")",
				"-moz-transform": property + "("+size+")",
				"-ms-transform": property + "("+size+")",
				"-o-transform": property + "("+size+")",
				"transform": property + "("+size+")"
		   });
		   cont_m=='n'+(lcont+1);
		 }
	  }
  });

  $(".nav_tl .next").on("click", function(){
     if(cont_m=='n10') {
	  	 event.preventDefault();
	  } else {
		 var obj = $("#"+wrap);
	    var trans=obj.css("transform")||obj.css("-moz-transform")||obj.css("-ms-transform")||obj.css("-o-transform")||obj.css("-webkit-transform");
		 var mt=trans.replace(/[^0-9\-.,]/g, '').split(',');
		 var x = mt[12] || mt[4];//translate x   mo�e by� wrap: wrap1 trans00: undefined
       var y = mt[13] || mt[5];//translate y
		 var li=wrap.replace("wrap","");
		 var lcont=	cont_m.replace("n","");
		 if(typeof x==="undefined"){
		 } else {
		   var size= x/li+"px";
			var property="translateX"
		   obj.css({
		  		"-webkit-transform": property + "("+size+")",
				"-moz-transform": property + "("+size+")",
				"-ms-transform": property + "("+size+")",
				"-o-transform": property + "("+size+")",
				"transform": property + "("+size+")"
		   });
		   cont_m=='n'+(lcont-1);
		 }



	  }



  });


});